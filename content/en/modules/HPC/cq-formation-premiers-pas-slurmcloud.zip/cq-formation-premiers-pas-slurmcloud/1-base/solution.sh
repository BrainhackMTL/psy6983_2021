#!/bin/bash
#SBATCH --account=def-sponsor00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --time=2:00
#SBATCH --job-name=ex1

echo "Bonjour"
